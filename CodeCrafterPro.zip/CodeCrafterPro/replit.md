# BudgetByte Local - Smart Meal Planner for Kenyan Street & Local Foods

## Overview

BudgetByte Local is a Flask-based web application that helps budget-conscious users in Kenya discover and plan affordable meals. The application offers two main paths: cooking at home with traditional Kenyan recipes or purchasing ready-made street foods from local vendors. The platform also includes a vendor portal for food sellers to manage their business and make community donations.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Bootstrap 5 for responsive UI
- **Styling**: Custom CSS with primary theme colors (Green #4CAF50, Chocolate #7B3F00)
- **JavaScript**: Vanilla JavaScript for interactive components including meal selection, filtering, and form validation
- **Icons**: Font Awesome for consistent iconography

### Backend Architecture
- **Framework**: Flask (Python) with a simple route-based structure
- **Session Management**: Flask sessions for vendor authentication
- **Data Storage**: JSON files for meal data, locations, and vendor information (file-based storage)
- **Logging**: Python logging module for debugging and monitoring

### Key Components

1. **Meal Planning System**
   - Budget-based meal filtering
   - Two meal types: home cooking and street foods
   - Location-based filtering for street foods
   - Search and category filtering

2. **Vendor Management**
   - Simple authentication system using Flask sessions
   - Vendor dashboard with earnings display
   - Community donation system
   - Business registration with location selection

3. **Payment Simulation**
   - Mock payment system with multiple payment methods (M-PESA, Card, Pay on Delivery)
   - Order confirmation flow

## Data Flow

1. **User Journey**: Home page → Meal selection → Filtering → Recipe details → Payment
2. **Vendor Journey**: Registration/Login → Dashboard → Donations
3. **Data Loading**: JSON files loaded on-demand for meal data, locations, and vendor information
4. **Session Flow**: Vendor authentication stored in Flask sessions

## External Dependencies

### Frontend Dependencies
- Bootstrap 5.3.0 (CSS framework)
- Font Awesome 6.0.0 (icons)
- Pixabay images for meal photos

### Backend Dependencies
- Flask (web framework)
- Python standard library (json, logging, os)

### Data Sources
- Static JSON files for meal data
- Session-based vendor data storage
- No external databases currently integrated

## Deployment Strategy

- **Development**: Flask development server with debug mode
- **Host Configuration**: Configured for 0.0.0.0:5000 for external access
- **Environment Variables**: SESSION_SECRET for session security
- **Static Assets**: Served through Flask's static file handling
- **Templates**: Jinja2 template inheritance with base template

## Technical Decisions

### Data Storage Choice
- **Decision**: JSON files for data persistence
- **Rationale**: Simple setup, no database configuration needed
- **Trade-offs**: Limited scalability but easier development and deployment

### Authentication Approach
- **Decision**: Session-based authentication for vendors
- **Rationale**: Simple implementation without external auth providers
- **Trade-offs**: Basic security model, suitable for demo/prototype

### Frontend Framework
- **Decision**: Bootstrap + vanilla JavaScript
- **Rationale**: Rapid prototyping, responsive design, no complex build process
- **Trade-offs**: Less dynamic than modern frameworks but simpler to maintain

### File Structure
- **Decision**: Organized by function (templates, static, data)
- **Rationale**: Clear separation of concerns, easy to navigate
- **Trade-offs**: Standard Flask structure, familiar to developers

## Future Considerations

The application is designed to easily integrate with a proper database system (likely PostgreSQL with Drizzle ORM) when scaling beyond the prototype phase. The current JSON-based data storage can be migrated to database tables while maintaining the same application logic.