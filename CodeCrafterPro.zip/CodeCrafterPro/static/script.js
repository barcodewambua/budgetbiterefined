// BudgetByte Local - Interactive JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all interactive components
    initMealSelection();
    initFilterForm();
    initPaymentForm();
    initDonationForm();
    initPasswordToggle();
    initFormValidation();
    initScrollAnimations();
    initQuickAmountSelection();
});

// Meal Type Selection on Homepage
function initMealSelection() {
    const mealOptions = document.querySelectorAll('.meal-option-card');
    const mealTypeInput = document.getElementById('meal_type');
    
    if (mealOptions.length > 0 && mealTypeInput) {
        mealOptions.forEach(option => {
            option.addEventListener('click', function() {
                const mealType = this.dataset.mealType;
                
                // Remove active class from all options
                mealOptions.forEach(opt => {
                    opt.querySelector('.meal-option').classList.remove('active');
                });
                
                // Add active class to clicked option
                this.querySelector('.meal-option').classList.add('active');
                
                // Update hidden input value
                mealTypeInput.value = mealType;
                
                // Add visual feedback
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                }, 150);
            });
        });
    }
}

// Filter Form Auto-Submit
function initFilterForm() {
    const filterForm = document.getElementById('filterForm');
    if (filterForm) {
        const filterInputs = filterForm.querySelectorAll('input, select');
        
        // Add change event listeners to auto-submit form
        filterInputs.forEach(input => {
            if (input.type !== 'submit') {
                input.addEventListener('change', function() {
                    // Add loading state
                    const submitBtn = filterForm.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        const originalText = submitBtn.innerHTML;
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Filtering...';
                        submitBtn.disabled = true;
                        
                        setTimeout(() => {
                            filterForm.submit();
                        }, 300);
                    }
                });
            }
        });
    }
}

// Payment Form Functionality
function initPaymentForm() {
    const paymentForm = document.getElementById('paymentForm');
    if (paymentForm) {
        const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
        const paymentDetails = document.querySelectorAll('.payment-details');
        
        // Payment method switching
        paymentMethods.forEach(method => {
            method.addEventListener('change', function() {
                const selectedMethod = this.value;
                
                // Hide all payment details
                paymentDetails.forEach(detail => {
                    detail.style.display = 'none';
                });
                
                // Show selected payment method details
                const selectedDetails = document.getElementById(`${selectedMethod}-details`);
                if (selectedDetails) {
                    selectedDetails.style.display = 'block';
                    
                    // Animate in
                    selectedDetails.style.opacity = '0';
                    selectedDetails.style.transform = 'translateY(20px)';
                    
                    requestAnimationFrame(() => {
                        selectedDetails.style.transition = 'all 0.3s ease';
                        selectedDetails.style.opacity = '1';
                        selectedDetails.style.transform = 'translateY(0)';
                    });
                }
                
                // Update submit button text
                updateSubmitButtonText(selectedMethod);
            });
        });
        
        // Form submission with loading state
        paymentForm.addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
            submitBtn.disabled = true;
            
            // Add loading class to form
            paymentForm.classList.add('loading');
            
            // Re-enable after a delay (for demo purposes)
            setTimeout(() => {
                paymentForm.classList.remove('loading');
            }, 2000);
        });
        
        // Card number formatting
        const cardNumberInput = document.querySelector('input[placeholder="1234 5678 9012 3456"]');
        if (cardNumberInput) {
            cardNumberInput.addEventListener('input', function() {
                let value = this.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
                let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
                this.value = formattedValue;
            });
        }
        
        // Expiry date formatting
        const expiryInput = document.querySelector('input[placeholder="MM/YY"]');
        if (expiryInput) {
            expiryInput.addEventListener('input', function() {
                let value = this.value.replace(/\D/g, '');
                if (value.length >= 2) {
                    value = value.substring(0, 2) + '/' + value.substring(2, 4);
                }
                this.value = value;
            });
        }
    }
}

// Update submit button text based on payment method
function updateSubmitButtonText(method) {
    const submitText = document.getElementById('submitText');
    const submitBtn = document.getElementById('submitBtn');
    
    if (submitText && submitBtn) {
        let icon = '<i class="fas fa-lock me-2"></i>';
        let text = '';
        
        switch (method) {
            case 'mpesa':
                icon = '<i class="fas fa-mobile-alt me-2"></i>';
                text = 'Pay with M-PESA';
                break;
            case 'card':
                icon = '<i class="fas fa-credit-card me-2"></i>';
                text = 'Pay with Card';
                break;
            case 'cash':
                icon = '<i class="fas fa-truck me-2"></i>';
                text = 'Confirm Order';
                break;
        }
        
        submitBtn.innerHTML = icon + text + ' - ' + submitText.textContent.split(' - ')[1];
    }
}

// Donation Form Functionality
function initDonationForm() {
    const donationForm = document.querySelector('.donation-form');
    if (donationForm) {
        const quickAmountButtons = document.querySelectorAll('.quick-amount');
        const amountInput = donationForm.querySelector('input[type="number"]');
        
        // Quick amount selection
        quickAmountButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const amount = this.dataset.amount;
                
                // Remove active class from all buttons
                quickAmountButtons.forEach(btn => btn.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                // Set amount in input
                if (amountInput) {
                    amountInput.value = amount;
                    
                    // Animate input field
                    amountInput.style.transform = 'scale(1.05)';
                    amountInput.style.borderColor = 'var(--primary-green)';
                    
                    setTimeout(() => {
                        amountInput.style.transform = '';
                        amountInput.style.borderColor = '';
                    }, 300);
                }
            });
        });
        
        // Form submission
        donationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show success message
            const organization = this.querySelector('select').selectedOptions[0]?.text || 'the organization';
            const amount = this.querySelector('input[type="number"]').value;
            
            if (amount && amount >= 100) {
                showSuccessMessage(`Thank you! Your donation of KES ${amount} to ${organization} has been processed successfully.`);
                this.reset();
                quickAmountButtons.forEach(btn => btn.classList.remove('active'));
            } else {
                showErrorMessage('Please select an organization and enter a donation amount of at least KES 100.');
            }
        });
    }
}

// Password Toggle Functionality
function initPasswordToggle() {
    window.togglePassword = function(inputId) {
        const passwordInput = document.getElementById(inputId);
        const toggleIcon = document.getElementById(`${inputId}-toggle`);
        
        if (passwordInput && toggleIcon) {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    };
}

// Form Validation
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Find first invalid field and focus it
                const firstInvalidField = form.querySelector(':invalid');
                if (firstInvalidField) {
                    firstInvalidField.focus();
                    firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }
            form.classList.add('was-validated');
        });
        
        // Real-time validation for password confirmation
        const password = form.querySelector('#password');
        const confirmPassword = form.querySelector('#confirm_password');
        
        if (password && confirmPassword) {
            function validatePasswords() {
                if (confirmPassword.value && password.value !== confirmPassword.value) {
                    confirmPassword.setCustomValidity('Passwords do not match');
                } else {
                    confirmPassword.setCustomValidity('');
                }
            }
            
            password.addEventListener('input', validatePasswords);
            confirmPassword.addEventListener('input', validatePasswords);
        }
    });
}

// Scroll Animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animateElements = document.querySelectorAll('.feature-card, .meal-card, .stats-card');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
}

// Quick Amount Selection for Donations
function initQuickAmountSelection() {
    const quickAmountButtons = document.querySelectorAll('.quick-amount');
    const amountInput = document.querySelector('input[name="amount"]');
    
    quickAmountButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const amount = parseInt(this.dataset.amount);
            
            // Update input value
            if (amountInput) {
                amountInput.value = amount;
            }
            
            // Update button states
            quickAmountButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Visual feedback
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
}

// Utility Functions
function showSuccessMessage(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-success alert-dismissible fade show position-fixed';
    alertContainer.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
    alertContainer.innerHTML = `
        <i class="fas fa-check-circle me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertContainer);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertContainer.parentNode) {
            alertContainer.parentNode.removeChild(alertContainer);
        }
    }, 5000);
}

function showErrorMessage(message) {
    const alertContainer = document.createElement('div');
    alertContainer.className = 'alert alert-danger alert-dismissible fade show position-fixed';
    alertContainer.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
    alertContainer.innerHTML = `
        <i class="fas fa-exclamation-triangle me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(alertContainer);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alertContainer.parentNode) {
            alertContainer.parentNode.removeChild(alertContainer);
        }
    }, 5000);
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Mobile menu enhancement
const navbarToggler = document.querySelector('.navbar-toggler');
const navbarCollapse = document.querySelector('.navbar-collapse');

if (navbarToggler && navbarCollapse) {
    // Close mobile menu when clicking on a link
    const navLinks = navbarCollapse.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navbarCollapse.classList.contains('show')) {
                navbarToggler.click();
            }
        });
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (navbarCollapse.classList.contains('show') && 
            !navbarCollapse.contains(e.target) && 
            !navbarToggler.contains(e.target)) {
            navbarToggler.click();
        }
    });
}

// Image lazy loading fallback for older browsers
if ('IntersectionObserver' in window) {
    const lazyImages = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    lazyImages.forEach(img => imageObserver.observe(img));
}

// Performance optimization: Debounce resize events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle window resize for responsive adjustments
const handleResize = debounce(() => {
    // Add any resize handling logic here
    console.log('Window resized');
}, 250);

window.addEventListener('resize', handleResize);

// Service Worker registration for offline functionality (if needed)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Uncomment the following lines if you want to add service worker support
        // navigator.serviceWorker.register('/sw.js')
        //     .then(registration => console.log('SW registered: ', registration))
        //     .catch(registrationError => console.log('SW registration failed: ', registrationError));
    });
}

console.log('BudgetByte Local - JavaScript initialized successfully!');
