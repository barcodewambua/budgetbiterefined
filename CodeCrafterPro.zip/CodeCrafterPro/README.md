# BudgetByte Local - Smart Meal Planner for Kenyan Street & Local Foods

BudgetByte Local is a Flask-based web application that helps budget-conscious users in Kenya discover and plan affordable meals. The platform offers two main paths: cooking at home with traditional Kenyan recipes or purchasing ready-made street foods from local vendors. It also includes a vendor portal for food sellers to manage their business and participate in community donations.

## Features

### 🍽️ User Features
- **Budget-Based Meal Planning**: Enter your budget (KES 20-2000) to find suitable meals
- **Dual Meal Options**:
  - **Cook at Home**: Traditional Kenyan recipes with ingredients and cooking instructions
  - **Buy Ready-Made**: Authentic street foods from local vendors
- **Advanced Filtering**: Filter by location, category, search terms, and nutritional preferences
- **Detailed Recipe Views**: Complete nutritional information, cooking instructions, and ingredient lists
- **Mock Payment System**: Supports M-PESA, Card payments, and Cash on Delivery

### 🏪 Vendor Features
- **Vendor Registration & Login**: Simple authentication system for food vendors
- **Dashboard Analytics**: View earnings, orders, and performance metrics
- **Community Donations**: Participate in local food initiatives and charity programs
- **Business Management**: Manage vendor profile and location settings

### 🗺️ Location-Based Services
- **15 Kenyan Locations**: CBD, Westlands, Eastleigh, Kibera, Mathare, and more
- **Zone-Based Organization**: Areas organized by geographical zones
- **Vendor Location Matching**: Find street food vendors in your area

## Data Content

- **30+ Street Food Items**: Authentic Kenyan street foods with prices from KES 20-1000
- **30+ Home Cooking Recipes**: Traditional meals with full ingredient lists and cooking instructions
- **Complete Nutritional Data**: Calories, protein, carbs, fat, fiber, sodium, vitamins for every meal
- **Vendor Information**: Real vendor names and location data for street foods

## Tech Stack

- **Backend**: Flask (Python 3.11+)
- **Frontend**: Bootstrap 5, Vanilla JavaScript, Font Awesome icons
- **Data Storage**: JSON files (easily migrateable to database)
- **Styling**: Custom CSS with green/white/chocolate theme
- **Session Management**: Flask sessions for vendor authentication

## Project Structure

```
BudgetByte-Local/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── data/                 # JSON data files
│   ├── street_foods.json # Street food data
│   ├── home_meals.json   # Home cooking recipes
│   └── locations.json    # Available locations
├── templates/            # Jinja2 HTML templates
│   ├── base.html        # Base template with navigation
│   ├── index.html       # Homepage
│   ├── meals.html       # Meals listing page
│   ├── recipe.html      # Recipe detail page
│   ├── login.html       # Vendor login
│   ├── signup.html      # Vendor registration
│   ├── vendor_dashboard.html # Vendor dashboard
│   ├── donations.html   # Donations page
│   └── payment_mock.html # Payment simulation
├── static/              # Static assets
│   ├── style.css       # Custom CSS styles
│   └── script.js       # Interactive JavaScript
├── pyproject.toml      # Python dependencies
├── uv.lock            # Dependency lock file
└── README.md          # This file
```

## Installation & Setup

### Prerequisites
- Python 3.11 or higher
- pip or uv package manager

### 1. Clone the Repository
```bash
git clone <repository-url>
cd BudgetByte-Local
```

### 2. Install Dependencies
Using pip:
```bash
pip install flask gunicorn
```

Using uv (recommended):
```bash
uv sync
```

### 3. Set Environment Variables
Create a `.env` file or set environment variables:
```bash
# Required for session security
export SESSION_SECRET="your-secret-key-here"

# Optional: Set Flask environment
export FLASK_ENV=development
export FLASK_DEBUG=1
```

### 4. Run the Application

#### Development Mode (Flask dev server):
```bash
python main.py
```

#### Production Mode (Gunicorn):
```bash
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

#### Using the Replit Workflow:
The application is configured to run with Gunicorn on Replit. Simply start the "Start application" workflow.

### 5. Access the Application
Open your browser and navigate to:
- Local development: `http://localhost:5000`
- Replit deployment: `https://<repl-name>.<username>.replit.app`

## Usage Guide

### For Users (Meal Planning)

1. **Homepage**: 
   - Enter your budget in KES (20-2000)
   - Select your location from the dropdown
   - Choose between "Cook at Home" or "Buy Ready-Made"
   - Click "Find Meals"

2. **Meals Page**:
   - Browse filtered meals based on your criteria
   - Use additional filters (search, category, location)
   - View nutritional quick facts for each meal
   - Click "View Details" for complete recipe information

3. **Recipe Page**:
   - View complete cooking instructions or preparation details
   - Check detailed nutritional information
   - See ingredient lists (for home cooking)
   - Click "Get Ingredients" or "Order Now" to proceed to payment

4. **Payment**:
   - Choose payment method (M-PESA, Card, or Cash on Delivery)
   - Fill in payment details (demo system)
   - Complete the mock transaction

### For Vendors

1. **Registration**:
   - Click "Vendor Login" in the navigation
   - Click "Sign up here" to create a new account
   - Fill in business information, contact details, and location
   - Create account credentials

2. **Dashboard**:
   - View earnings statistics (today, week, month)
   - Monitor order counts and pending orders
   - Access quick actions for business management
   - View popular meals performance

3. **Donations**:
   - Access the donations page from the dashboard
   - Select an organization to support
   - Choose donation amount or use quick amount buttons
   - Submit donation to help the community

## Configuration

### Data Management
The application uses JSON files for data storage, located in the `data/` directory:

- `street_foods.json`: Contains street food items with vendor and location information
- `home_meals.json`: Contains home cooking recipes with ingredients and instructions
- `locations.json`: Defines available locations and their zones

### Customization
- **Theme Colors**: Modify CSS variables in `static/style.css`
- **Locations**: Add new locations in `data/locations.json`
- **Meals**: Add new meals in the respective JSON files
- **Payment Methods**: Customize payment options in `templates/payment_mock.html`

## Development Features

### Mock Systems
- **Authentication**: Simple session-based vendor login (not for production)
- **Payment Processing**: Simulated payment with 75% success rate
- **Data Persistence**: Session-based data storage (demo purposes)

### Responsive Design
- Mobile-first Bootstrap 5 implementation
- Optimized for phones, tablets, and desktop
- Touch-friendly interface elements

### Interactive Elements
- Real-time form validation
- Dynamic meal type selection
- Auto-submitting filter forms
- Payment method switching
- Quick amount selection for donations

## API Endpoints

### Public Routes
- `GET /` - Homepage with meal planning interface
- `GET /meals` - Meals listing with filtering
- `GET /recipe/<id>` - Individual recipe details
- `GET /payment/<id>` - Payment page for specific meal

### Vendor Routes
- `GET/POST /login` - Vendor authentication
- `GET/POST /signup` - Vendor registration
- `GET /vendor_dashboard` - Vendor dashboard (requires login)
- `GET /donations` - Donations management (requires login)
- `GET /logout` - Vendor logout

### Payment Routes
- `POST /payment_process` - Process payment submission

## Security Considerations

### Current Implementation (Demo)
- Session-based authentication without password hashing
- No input sanitization or CSRF protection
- Mock payment processing without real transactions
- JSON file storage instead of secure database

### Production Recommendations
- Implement proper user authentication with password hashing
- Add CSRF protection and input validation
- Use a proper database (PostgreSQL recommended)
- Integrate real payment gateways (M-PESA API, Stripe)
- Add SSL/TLS encryption
- Implement rate limiting and security headers

## Deployment

### Replit Deployment
The application is ready for Replit deployment with:
- Gunicorn WSGI server configuration
- Environment variable management
- Automatic workflow configuration

### Other Platforms
For deployment on other platforms, consider:
- Setting up a proper database
- Configuring environment variables
- Setting up SSL certificates
- Implementing proper logging and monitoring

## Troubleshooting

### Common Issues

1. **Module Not Found Errors**:
   ```bash
   # Reinstall dependencies
   pip install -r requirements.txt
   # or
   uv sync
   ```

2. **Port Already in Use**:
   ```bash
   # Kill existing process
   lsof -ti:5000 | xargs kill -9
   ```

3. **JSON File Errors**:
   ```bash
   # Validate JSON files
   python -m json.tool data/street_foods.json
   python -m json.tool data/home_meals.json
   python -m json.tool data/locations.json
   ```

4. **Session Issues**:
   - Ensure SESSION_SECRET environment variable is set
   - Clear browser cookies if experiencing login issues

### Debug Mode
Enable debug mode for development:
```bash
export FLASK_DEBUG=1
python main.py
```

## Contributing

### Data Contributions
- Add new Kenyan meals to the JSON files
- Ensure nutritional data is accurate
- Include proper vendor and location information

### Code Contributions
- Follow PEP 8 Python style guidelines
- Maintain Bootstrap 5 compatibility
- Test responsive design on multiple devices
- Ensure accessibility compliance

## License

This project is created for educational and demonstration purposes. Please ensure proper licensing before commercial use.

## Support

For technical support or questions about the project:
1. Check the troubleshooting section above
2. Review the console logs for error messages
3. Verify all dependencies are properly installed
4. Ensure data files are not corrupted

## Future Enhancements

### Planned Features
- Real database integration (PostgreSQL with Drizzle ORM)
- Actual M-PESA payment integration
- User accounts and meal planning history
- Vendor meal management interface
- Order tracking and delivery system
- Advanced nutrition tracking and recommendations
- Multi-language support (English/Swahili)

### Technical Improvements
- API-first architecture with REST endpoints
- Real-time order tracking with WebSockets
- Advanced search with Elasticsearch
- Image upload and management for meals
- SMS notifications for orders
- Progressive Web App (PWA) capabilities

---

**BudgetByte Local** - Empowering affordable nutrition choices across Kenya! 🇰🇪