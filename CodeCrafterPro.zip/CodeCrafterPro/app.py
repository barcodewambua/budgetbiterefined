import os
import json
import logging
import random
from flask import Flask, render_template, request, redirect, url_for, flash, session

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "your-secret-key-here")

# Helper function to load JSON data
def load_json_data(filename):
    try:
        with open(f'data/{filename}', 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        logging.error(f"Data file {filename} not found")
        return []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/meals')
def meals():
    meal_type = request.args.get('type', 'street_food')
    budget = request.args.get('budget', 0, type=int)
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    
    # Load appropriate data based on meal type
    if meal_type == 'home_cooking':
        meals_data = load_json_data('home_meals.json')
    else:
        meals_data = load_json_data('street_foods.json')
    
    # Filter meals based on criteria
    filtered_meals = []
    for meal in meals_data:
        # Budget filter
        if budget > 0 and meal['price'] > budget:
            continue
        
        # Search filter
        if search and search.lower() not in meal['name'].lower():
            continue
        
        # Category filter
        if category and meal.get('category', '').lower() != category.lower():
            continue
        
        filtered_meals.append(meal)
    
    # Get unique categories for filter dropdown
    categories = list(set([meal.get('category', 'Budget') for meal in meals_data]))
    
    return render_template('meals.html', 
                         meals=filtered_meals, 
                         meal_type=meal_type,
                         budget=budget,
                         search=search,
                         category=category,
                         categories=categories)

@app.route('/recipe/<int:meal_id>')
def recipe(meal_id):
    meal_type = request.args.get('type', 'street_food')
    
    # Load appropriate data based on meal type
    if meal_type == 'home_cooking':
        meals_data = load_json_data('home_meals.json')
    else:
        meals_data = load_json_data('street_foods.json')
    
    # Find the specific meal
    meal = None
    for m in meals_data:
        if m['id'] == meal_id:
            meal = m
            break
    
    if not meal:
        flash('Meal not found!', 'error')
        return redirect(url_for('meals', type=meal_type))
    
    return render_template('recipe.html', meal=meal, meal_type=meal_type)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Mock authentication - in production, you'd verify against a database
        if email and password:
            session['vendor_email'] = email
            session['vendor_name'] = email.split('@')[0].replace('.', ' ').title()
            flash('Successfully logged in!', 'success')
            return redirect(url_for('vendor_dashboard'))
        else:
            flash('Please enter both email and password!', 'error')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        business_name = request.form.get('business_name')
        email = request.form.get('email')
        contact = request.form.get('contact')
        password = request.form.get('password')
        
        # Mock signup - in production, you'd save to database
        if all([business_name, email, contact, password]):
            session['vendor_email'] = email
            session['vendor_name'] = business_name
            session['vendor_contact'] = contact
            flash('Account created successfully!', 'success')
            return redirect(url_for('vendor_dashboard'))
        else:
            flash('Please fill in all fields!', 'error')
    
    return render_template('signup.html')

@app.route('/vendor_dashboard')
def vendor_dashboard():
    if 'vendor_email' not in session:
        flash('Please log in to access the vendor dashboard!', 'error')
        return redirect(url_for('login'))
    
    # Mock data for dashboard
    mock_earnings = {
        'today': 2450,
        'this_week': 18750,
        'this_month': 87650,
        'total_orders': 156,
        'pending_orders': 8
    }
    
    return render_template('vendor_dashboard.html', earnings=mock_earnings)

@app.route('/donations')
def donations():
    if 'vendor_email' not in session:
        flash('Please log in to access donations!', 'error')
        return redirect(url_for('login'))
    
    # Mock donation data
    donations_data = [
        {'organization': 'Kibera Community Center', 'amount': 5000, 'date': '2025-07-18'},
        {'organization': 'Mathare Food Bank', 'amount': 3500, 'date': '2025-07-15'},
        {'organization': 'Street Children Support', 'amount': 2800, 'date': '2025-07-10'},
    ]
    
    return render_template('donations.html', donations=donations_data)

@app.route('/payment/<int:meal_id>')
def payment(meal_id):
    meal_type = request.args.get('type', 'street_food')
    
    # Load appropriate data based on meal type
    if meal_type == 'home_cooking':
        meals_data = load_json_data('home_meals.json')
    else:
        meals_data = load_json_data('street_foods.json')
    
    # Find the specific meal
    meal = None
    for m in meals_data:
        if m['id'] == meal_id:
            meal = m
            break
    
    if not meal:
        flash('Meal not found!', 'error')
        return redirect(url_for('meals', type=meal_type))
    
    return render_template('payment_mock.html', meal=meal, meal_type=meal_type)

@app.route('/payment_process', methods=['POST'])
def payment_process():
    meal_id = request.form.get('meal_id')
    payment_method = request.form.get('payment_method')
    amount = request.form.get('amount')
    
    # Mock payment processing
    success = random.choice([True, True, True, False])  # 75% success rate
    
    if success:
        flash(f'Payment of KES {amount} successful! Your order is being prepared.', 'success')
    else:
        flash('Payment failed. Please try again or use a different payment method.', 'error')
    
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    flash('Successfully logged out!', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
